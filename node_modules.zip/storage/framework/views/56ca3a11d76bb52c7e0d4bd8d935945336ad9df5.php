<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Just Us Group</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Acme&display=swap">
    <link rel="shortcut icon" type="image/x-icon" href="images/large/just-logo.png" />

    </head>
    <body>

            <?php echo $__env->yieldContent('content'); ?>




            <footer class="section">
      <div class="container">
        <p>All Copyright Reseved &copy;2020 just-us-group.com</p>
        <ul>
          <li><a target="_blank" class="facebook" href="https://www.facebook.com/Justusgroup-104479277909917"><i class="fa fa-fw fa-2x fa-inverse fa-facebook"></i></a></li>
          <li><a target="_blank" class="instagram" href="https://www.instagram.com/justusgroup/"><i class="fa fa-fw fa-2x fa-inverse fa-instagram"></i></a></li>
        </ul>
      </div>
    </footer>

</div><!-- #page -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="js/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/fontawesome.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/navigation.js"></script>
    <script src="js/customizer.js"></script>



</body>
</html>
<?php /**PATH C:\Users\smartech17\justus\justusgroup\resources\views/layouts/layout.blade.php ENDPATH**/ ?>